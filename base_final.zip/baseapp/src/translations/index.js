import { en } from './en';
import { ru } from './ru';
import { zh } from './zh';
export const languageMap = {
    default: en,
    en,
    ru,
    zh,
};