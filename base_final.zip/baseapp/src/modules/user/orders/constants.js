export const ORDER_EXECUTE_FETCH = 'orders/EXECUTE_FETCH';
export const ORDER_EXECUTE_DATA = 'orders/EXECUTE_DATA';
export const ORDER_EXECUTE_ERROR = 'orders/EXECUTE_ERROR';
export const ORDERS_SET_CURRENT_PRICE = 'orders/SET_CURRENT_PRICE';