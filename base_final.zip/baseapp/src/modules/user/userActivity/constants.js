export const USER_ACTIVITY_FETCH = 'userActivity/FETCH';
export const USER_ACTIVITY_DATA = 'userActivity/DATA';
export const USER_ACTIVITY_ERROR = 'userActivity/ERROR';