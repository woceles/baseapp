export const API_KEY_CREATE = 'api-keys/API_KEY_CREATE';
export const API_KEY_CREATE_FETCH = 'api-keys/API_KEY_CREATE_FETCH';
export const API_KEY_DELETE = 'api-keys/API_KEY_DELETE';
export const API_KEY_DELETE_FETCH = 'api-keys/API_KEY_DELETE_FETCH';
export const API_KEYS_FETCH = 'api-keys/API_KEYS_FETCH';
export const API_KEYS_DATA = 'api-keys/API_KEYS_DATA';
export const API_KEYS_2FA_MODAL = 'api-keys/API_KEYS_2FA_MODAL';
export const API_KEY_UPDATE = 'api-keys/API_KEY_UPDATE';
export const API_KEY_UPDATE_FETCH = 'api-keys/API_KEY_UPDATE_FETCH';