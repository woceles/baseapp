export const GET_LABEL_FETCH = 'confirm/GET_LABEL_FETCH';
export const GET_LABEL_DATA = 'confirm/GET_LABEL_DATA';
export const GET_LABEL_ERROR = 'confirm/GET_LABEL_ERROR';