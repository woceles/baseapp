export const selectLabelData = (state) => state.user.label.data;
export const selectLabelFetching = (state) => state.user.label.isFetching;