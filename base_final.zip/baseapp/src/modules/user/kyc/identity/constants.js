export const SEND_IDENTITY_ERROR = 'identity/SEND_IDENTITY_ERROR';
export const SEND_IDENTITY_FETCH = 'identity/SEND_IDENTITY_FETCH';
export const SEND_IDENTITY_DATA = 'identity/SEND_IDENTITY_DATA';