export const selectSendIdentitySuccess = (state) => state.user.identity.success;
export const selectSendIdentityError = (state) => state.user.identity.error;