export const selectSendDocumentsSuccess = (state) => state.user.documents.success;
export const selectSendDocumentsLoading = (state) => state.user.documents.loading;