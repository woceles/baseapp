export const sendPhoneCode = (state) => state.user.phone.codeSend;
export const selectVerifyPhoneSuccess = (state) => state.user.phone.successMessage;