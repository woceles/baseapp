export const PHONE_SEND_CODE_ERROR = 'phone/SEND_CODE_ERROR';
export const PHONE_SEND_CODE_FETCH = 'phone/SEND_CODE_FETCH';
export const PHONE_SEND_CODE_DATA = 'phone/SEND_CODE_DATA';
export const PHONE_VERIFY_ERROR = 'phone/VERIFY_PHONE_ERROR';
export const PHONE_VERIFY_DATA = 'phone/VERIFY_PHONE_DATA';
export const PHONE_VERIFY_FETCH = 'phone/VERIFY_PHONE_FETCH';
export const PHONE_RESEND_CODE_ERROR = 'phone/RESEND_CODE_ERROR';
export const PHONE_RESEND_CODE_FETCH = 'phone/RESEND_CODE_FETCH';
export const PHONE_RESEND_CODE_DATA = 'phone/RESEND_CODE_DATA';