export const NEW_HISTORY_FETCH = 'newHistory/FETCH';
export const NEW_HISTORY_DATA = 'newHistory/DATA';
export const NEW_HISTORY_ERROR = 'newHistory/ERROR';
export const NEW_HISTORY_RESET = 'newHistory/RESET';