export const selectNewHistory = (state) => state.user.newHistory.list;
export const selectNewHistoryLoading = (state) => state.user.newHistory.fetching;