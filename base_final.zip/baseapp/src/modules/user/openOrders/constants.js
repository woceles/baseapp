export const OPEN_ORDERS_FETCH = 'openOrders/FETCH';
export const OPEN_ORDERS_DATA = 'openOrders/DATA';
export const OPEN_ORDERS_ERROR = 'openOrders/ERROR';
export const OPEN_ORDERS_APPEND = 'openOrders/APPEND';
export const OPEN_ORDERS_UPDATE = 'openOrders/UPDATE';
export const OPEN_ORDERS_RESET = 'openOrders/RESET';
export const OPEN_ORDERS_CANCEL_FETCH = 'openOrders/CANCEL_FETCH';
export const OPEN_ORDERS_CANCEL_DATA = 'openOrders/CANCEL_DATA';
export const OPEN_ORDERS_CANCEL_ERROR = 'openOrders/CANCEL_ERROR';