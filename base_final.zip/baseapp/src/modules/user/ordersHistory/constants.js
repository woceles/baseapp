export const ORDERS_HISTORY_FETCH = 'ordersHistory/FETCH';
export const ORDERS_HISTORY_DATA = 'ordersHistory/DATA';
export const ORDERS_HISTORY_ERROR = 'ordersHistory/ERROR';
export const ORDERS_TEST_HISTORY_STATE = 'ordersHistory/TEST_STATE';
export const ORDERS_CANCEL_ALL_FETCH = 'ordersHistory/CANCEL_ALL_FETCH';
export const ORDERS_CANCEL_ALL_DATA = 'ordersHistory/CANCEL_ALL_DATA';
export const ORDERS_CANCEL_ALL_ERROR = 'ordersHistory/CANCEL_ALL_ERROR';
export const ORDERS_HISTORY_CANCEL_FETCH = 'ordersHistory/CANCEL_FETCH';
export const ORDERS_HISTORY_CANCEL_DATA = 'ordersHistory/CANCEL_DATA';
export const ORDERS_HISTORY_CANCEL_ERROR = 'ordersHistory/CANCEL_ERROR';
export const ORDERS_HISTORY_RESET = 'ordersHistory/RESET';