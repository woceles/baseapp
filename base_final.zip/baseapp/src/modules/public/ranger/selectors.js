export const selectRanger = (state) => state.public.ranger;
export const selectRangerIsConnected = (state) => state.public.ranger.connected;
export const selectSubscriptions = (state) => state.public.ranger.subscriptions;