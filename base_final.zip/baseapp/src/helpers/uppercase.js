export const uppercase = str => {
    return str ? str.toUpperCase() : str;
};