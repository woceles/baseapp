window.env = {
    api: {
        authUrl: 'http://Your_URL/api/v2/barong',
        tradeUrl: 'http://Your_URL/api/v2/peatio',
        applogicUrl: 'http://Your_URL/api/v2/applogic',
        rangerUrl: 'ws://Your_URL/api/v2/ranger',
    },
    minutesUntilAutoLogout: '60',
    withCredentials: false,
    captcha: {
        captchaType: 'none',
        siteKey: 'changeme',
    },
};