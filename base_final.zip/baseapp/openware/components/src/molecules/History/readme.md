```js
const data = [
  ['10:40', 'bid', 'BTC/USDT', 'Buy', '9.400,0', '0, 4005'],
  ['10:40', 'ask', 'BTC/USDT', 'Sell', '9.400,0', '0, 4005'],
  ['10:40', 'bid', 'BTC/USDT', 'Buy', '9.400,0', '0, 4005'],
];

<History data={data} />
```
