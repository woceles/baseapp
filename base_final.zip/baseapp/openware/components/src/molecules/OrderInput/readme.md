InputBlock example:

```js
  <OrderInput currency="eth" />
```
