WalletList example:

```js
<WalletItem
  address={'0xxabs0x'}
  currency="BTC"
  type={'fiat'}
  fee={0.4}
  amount={1.5501}
  locked={12}
  active={true}
/>
```
