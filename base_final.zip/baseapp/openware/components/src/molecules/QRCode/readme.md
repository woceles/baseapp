QRCode example:

```js
const address = 'kjsnvjkrv3434jnv';

<QRCode
  data={address}
  dimensions="lg"
  alt="my_qr_code"
/>
```
