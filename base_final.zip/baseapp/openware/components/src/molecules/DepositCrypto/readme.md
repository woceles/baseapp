DepositCrypto example:

```js
const address = 'kjsnvjkrv3434jnv';
const error = 'No data';
const text = 'Please submit a deposit payment using one of the following options. You deposit will be reflected in your account ofter 6 confirmation';

<DepositCrypto
  copyId="id"
  text={text}
  data={address}
  error={error}
/>
```
