InputBlock example:

```js
<InputBlock type="text" currency="BCH" message="Withdrawal Address" placeholder="Address" />
```
