
```js
const testData = ['Limit', 'Market'];

const onSelect = (value) => console.log(value);

<Dropdown
  list={testData}
  onSelect={onSelect}
/>

```
