WalletTradeItem example:

```js
<WalletTradeItem currency="btc" balance={1.5501} />
```
