GridItem example:

```js
<div className="bg-dark">
  <GridItem title="Title">Child Body</GridItem>
</div>
```
