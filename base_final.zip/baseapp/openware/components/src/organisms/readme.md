Сomplex UI components composed of groups of molecules and/or atoms. These organisms form distinct sections of an interface.

