Sign in form example:
```js
<SignInForm
    onForgotPassword={(email) => console.log(email)}
    onSignIn={(data) => console.log(data)}
    onSignUp={() => console.log('Sign up page')}
/>
```
