Sign up form example:
```js
<SignUpForm
    onSignIn={() => console.log('onSignIn')}
    onSignUp={data => console.log(data)}
/>
```
