Example of usage:

```js
  <SummaryField message="Fee" content="0.000111 BTC" borderItem="empty-circle" />
```
