```js
<AlertIcon type="success" />
<AlertIcon type="error" />
```