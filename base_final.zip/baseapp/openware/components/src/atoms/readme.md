Very simple building blocks of matter. These components are independent and highly customizable and can’t be broken down further. 
