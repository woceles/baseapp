Example of usage:

```js
<div className="centered-justified big">
    <CryptoIcon code="FTC-alt" />
    <CryptoIcon code="ETH">7.40</CryptoIcon>
    <CryptoIcon code="BTC"/>
    <CryptoIcon code="BTC-alt" />
</div>
```
