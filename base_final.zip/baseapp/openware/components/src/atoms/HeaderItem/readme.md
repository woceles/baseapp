Example of usage:

```js
  <HeaderItem label="24 hour price" amount={10.05} currency="btc" />
```