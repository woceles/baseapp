```js
<Alert description="30.052 BTC" title="Successful deposit" type="success" />
<Alert description="Internal server error" title="Withdraw failure" type="error" />
```