Example of usage:

```js
  <CopyableTextField fieldId="id1" value="1F1tAaz5x1HUXrCNLbtMDqcw6o5GNn4dfE" />
```
