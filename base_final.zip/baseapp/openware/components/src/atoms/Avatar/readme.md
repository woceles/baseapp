Example of usage:

```js
  <Avatar title="SS" />
```
