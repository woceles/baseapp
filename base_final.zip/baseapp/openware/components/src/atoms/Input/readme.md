Example of usage:

```js
  const handleChange = () => undefined;

  <Input type="text" placeholder="Placeholder" min="0" onChangeValue={handleChange} />
```
